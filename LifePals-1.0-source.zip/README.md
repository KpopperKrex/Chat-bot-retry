# LifePals

Admin-controlled simulated regulars for a Paper 1.21.11 lifesteal server. They chat in Hinglish/English, answer questions from a knowledge base you write, welcome players, react to deaths, and join/leave over time.

## Build (no PC needed)
1. Create a GitHub repo and upload everything in this folder (keep `.github/workflows/build.yml`).
2. Open the **Actions** tab, wait for the `build` run to finish, download the **LifePals** artifact (contains `LifePals.jar`).
   Or on a PC: `mvn package` (Java 21), jar is in `target/`.

## Install
1. Put `LifePals.jar` in `plugins/`, restart the server.
2. Edit `plugins/LifePals/knowledge.yml` (facts about YOUR server) and `config.yml` (chat format, mode).
3. `/pals reload`, then `/pals test hello` to try it privately.

## Modes (`brain.mode`)
- `OFFLINE`: no internet, uses knowledge.yml only.
- `API`: AI only. `AUTO`: AI first, offline fallback.
- API key: `brain.api-key` or env var `LIFEPALS_API_KEY`. Use a separate key with a low spend limit.
- `provider: anthropic` or `openai` (set `base-url` for Groq/OpenRouter/Gemini-compatible endpoints).

## Commands (permission `lifepals.admin`, op by default)
`/pals status | list | say <bot> <msg> | join <bot> | leave <bot> | reroll | toggle | test <msg> | reload`

## Safety design
- Bots are not players: no permissions, no commands, no inventories. They only broadcast text.
- Output filter drops links, IPs, command-looking lines, secrets, AI/prompt talk and blocked words.
- Input scrub removes links/IPs/color codes. API only receives persona prompt, your `facts`, and last ~8 chat lines.
- No network listeners, no file reads outside the plugin folder, no reflection, no other-plugin access.
- Remove: delete the jar and the `plugins/LifePals` folder. Nothing else is touched.

## Honest limits
- Bots are chat-only: they are not in the tab list, server list count or `/list`, and have no in-world body.
- Chat lines from real players go to the API provider in API/AUTO mode. Mention it in your rules/privacy notes.
