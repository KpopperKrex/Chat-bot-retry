package dev.lifepals;

import java.util.List;
import java.util.Locale;
import java.util.regex.Pattern;

/**
 * Safety layer. Everything going to the AI is scrubbed, everything coming back is
 * filtered before it can reach chat. Bots never run commands, they only produce text.
 */
final class Guard {
    private static final Pattern CODES = Pattern.compile("(?i)[§&][0-9a-fk-or]");
    private static final Pattern URL = Pattern.compile(
            "(?i)(https?://|www\\.|discord\\.gg|\\b[a-z0-9-]+\\.(com|net|org|gg|in|io|xyz|me|tk|ml)\\b)");
    private static final Pattern IP = Pattern.compile("\\b\\d{1,3}(\\.\\d{1,3}){3}(:\\d{2,5})?\\b");
    private static final Pattern NAME_PREFIX = Pattern.compile("^[\\w.]{2,16}:\\s+");

    private static final List<String> BUILT_IN_BLOCKED = List.of(
            "as an ai", "language model", "system prompt", "my instructions", "my prompt",
            "anthropic", "openai", "claude", "chatgpt", "gemini", "api key", "apikey",
            "password", "passwd", "token", "config.yml", "plugins folder", "console",
            "operator", "/op", "free op", "free rank", "free diamonds");

    private Guard() {
    }

    /** Clean a real player's chat line before it is stored or sent to an API. */
    static String in(String s) {
        if (s == null) {
            return "";
        }
        s = CODES.matcher(s).replaceAll("");
        s = s.replaceAll("[\\p{Cntrl}§]", " ");
        s = URL.matcher(s).replaceAll("[link]");
        s = IP.matcher(s).replaceAll("[ip]");
        s = s.replaceAll("\\s+", " ").strip();
        return s.length() > 160 ? s.substring(0, 160) : s;
    }

    /** Returns a safe chat line, or null if the line must be dropped. */
    static String out(String s, List<String> extraBlocked, String apiKey) {
        if (s == null) {
            return null;
        }
        s = s.strip();
        int nl = s.indexOf('\n');
        if (nl >= 0) {
            s = s.substring(0, nl).strip();
        }
        s = CODES.matcher(s).replaceAll("").replace("§", "");
        s = NAME_PREFIX.matcher(s).replaceFirst("");
        if (s.length() > 2 && s.startsWith("\"") && s.endsWith("\"")) {
            s = s.substring(1, s.length() - 1).strip();
        }
        if (s.isBlank() || s.equals("NOPE")) {
            return null;
        }
        if (s.startsWith("/") || s.startsWith("!") || s.startsWith(".")) {
            return null; // never look like a command
        }
        if (URL.matcher(s).find() || IP.matcher(s).find()) {
            return null;
        }
        String lower = s.toLowerCase(Locale.ROOT);
        for (String b : BUILT_IN_BLOCKED) {
            if (lower.contains(b)) {
                return null;
            }
        }
        if (extraBlocked != null) {
            for (String b : extraBlocked) {
                if (b != null && !b.isBlank() && lower.contains(b.toLowerCase(Locale.ROOT))) {
                    return null;
                }
            }
        }
        if (apiKey != null && apiKey.length() > 8 && s.contains(apiKey)) {
            return null;
        }
        if (s.length() > 110) {
            int cut = s.lastIndexOf(' ', 110);
            s = s.substring(0, cut > 20 ? cut : 110);
        }
        return s;
    }
}
