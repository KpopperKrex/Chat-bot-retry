package dev.lifepals;

import java.io.File;
import java.io.IOException;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Deque;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.concurrent.CompletableFuture;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.scheduler.BukkitTask;

/** Owns the roster and decides who says what and when. Bots only ever produce chat text. */
final class BotManager {

    static final class Bot {
        final Persona p;
        boolean online;
        long lastSpoke;

        Bot(Persona p) {
            this.p = p;
        }
    }

    private final LifePals plugin;
    private final Random rnd = new Random();
    private final List<Bot> roster = new ArrayList<>();
    private final Deque<ChatLine> history = new ArrayDeque<>();
    private final LegacyComponentSerializer legacy = LegacyComponentSerializer.legacyAmpersand();
    private BukkitTask task;
    private boolean enabled = true;
    private long nextChurn;
    private long nextAmbient;
    private long lastAny;

    BotManager(LifePals plugin) {
        this.plugin = plugin;
    }

    private FileConfiguration cfg() {
        return plugin.getConfig();
    }

    // ---------------------------------------------------------------- lifecycle

    void start() {
        reload();
        task = Bukkit.getScheduler().runTaskTimer(plugin, this::tick, 100L, 100L);
    }

    void stop() {
        if (task != null) {
            task.cancel();
        }
    }

    void reload() {
        enabled = cfg().getBoolean("enabled", true);
        loadRoster(false);
        long now = System.currentTimeMillis();
        nextChurn = now + ms(rand(cfg().getInt("bots.churn-min-seconds", 150), cfg().getInt("bots.churn-max-seconds", 480)));
        nextAmbient = now + ms(rand(cfg().getInt("chat.ambient-min-seconds", 100), cfg().getInt("chat.ambient-max-seconds", 260)));
        bringMinOnlineSilently();
    }

    void reroll() {
        loadRoster(true);
        bringMinOnlineSilently();
    }

    // ---------------------------------------------------------------- roster

    private List<Persona> loadPool() {
        YamlConfiguration y = YamlConfiguration.loadConfiguration(new File(plugin.getDataFolder(), "personas.yml"));
        List<Persona> out = new ArrayList<>();
        for (Map<?, ?> m : y.getMapList("personas")) {
            try {
                out.add(Persona.fromMap(m));
            } catch (Exception ignored) {
                // skip malformed persona
            }
        }
        return out;
    }

    private void loadRoster(boolean fresh) {
        List<Persona> pool = loadPool();
        File f = new File(plugin.getDataFolder(), "data.yml");
        List<String> saved = fresh ? List.of() : YamlConfiguration.loadConfiguration(f).getStringList("roster");
        int want = Math.max(1, cfg().getInt("bots.count", 8));

        roster.clear();
        for (String n : saved) {
            for (Persona p : pool) {
                if (p.name().equalsIgnoreCase(n) && roster.size() < want) {
                    roster.add(new Bot(p));
                    break;
                }
            }
        }
        List<Persona> shuffled = new ArrayList<>(pool);
        Collections.shuffle(shuffled, rnd);
        for (Persona p : shuffled) {
            if (roster.size() >= want) {
                break;
            }
            boolean already = roster.stream().anyMatch(b -> b.p.name().equalsIgnoreCase(p.name()));
            if (!already && nameIsFree(p.name())) {
                roster.add(new Bot(p));
            }
        }

        YamlConfiguration d = new YamlConfiguration();
        List<String> names = new ArrayList<>();
        for (Bot b : roster) {
            names.add(b.p.name());
        }
        d.set("roster", names);
        try {
            d.save(f);
        } catch (IOException e) {
            plugin.getLogger().warning("Could not save data.yml");
        }
    }

    /** Never reuse the name of a real player who is online or has played here. */
    private boolean nameIsFree(String name) {
        return Bukkit.getPlayerExact(name) == null && Bukkit.getOfflinePlayerIfCached(name) == null;
    }

    private void bringMinOnlineSilently() {
        for (Bot b : roster) {
            b.online = false;
        }
        List<Bot> shuffled = new ArrayList<>(roster);
        Collections.shuffle(shuffled, rnd);
        int min = cfg().getInt("bots.min-online", 3);
        for (int i = 0; i < Math.min(min, shuffled.size()); i++) {
            shuffled.get(i).online = true;
        }
    }

    List<Bot> roster() {
        return roster;
    }

    Bot find(String name) {
        for (Bot b : roster) {
            if (b.p.name().equalsIgnoreCase(name)) {
                return b;
            }
        }
        return null;
    }

    int onlineCount() {
        int n = 0;
        for (Bot b : roster) {
            if (b.online) {
                n++;
            }
        }
        return n;
    }

    boolean enabled() {
        return enabled;
    }

    void setEnabled(boolean e) {
        enabled = e;
    }

    // ---------------------------------------------------------------- join / leave

    void join(Bot b) {
        if (b.online) {
            return;
        }
        b.online = true;
        if (cfg().getBoolean("messages.show-join-leave", true)) {
            announce(cfg().getString("messages.join", "&e{name} joined the game"), b);
        }
    }

    void leave(Bot b) {
        if (!b.online) {
            return;
        }
        b.online = false;
        if (cfg().getBoolean("messages.show-join-leave", true)) {
            announce(cfg().getString("messages.leave", "&e{name} left the game"), b);
        }
    }

    private void announce(String fmt, Bot b) {
        Bukkit.broadcast(legacy.deserialize(fmt.replace("{name}", b.p.name())));
    }

    // ---------------------------------------------------------------- scheduler tick

    private void tick() {
        if (!enabled) {
            return;
        }
        long now = System.currentTimeMillis();
        if (now >= nextChurn) {
            churn();
            nextChurn = now + ms(rand(cfg().getInt("bots.churn-min-seconds", 150), cfg().getInt("bots.churn-max-seconds", 480)));
        }
        if (now >= nextAmbient) {
            nextAmbient = now + ms(rand(cfg().getInt("chat.ambient-min-seconds", 100), cfg().getInt("chat.ambient-max-seconds", 260)));
            boolean needPlayers = cfg().getBoolean("chat.only-when-players-online", true);
            if (!needPlayers || !Bukkit.getOnlinePlayers().isEmpty()) {
                Bot b = pickSpeaker(null);
                if (b != null) {
                    respond(b, null, false, 0);
                }
            }
        }
    }

    private void churn() {
        int on = onlineCount();
        int min = cfg().getInt("bots.min-online", 3);
        int max = cfg().getInt("bots.max-online", 6);
        if (on < min || (on < max && rnd.nextBoolean())) {
            List<Bot> off = new ArrayList<>();
            for (Bot b : roster) {
                if (!b.online) {
                    off.add(b);
                }
            }
            if (!off.isEmpty()) {
                join(off.get(rnd.nextInt(off.size())));
            }
        } else if (on > min) {
            List<Bot> onl = new ArrayList<>();
            for (Bot b : roster) {
                if (b.online) {
                    onl.add(b);
                }
            }
            if (!onl.isEmpty()) {
                leave(onl.get(rnd.nextInt(onl.size())));
            }
        }
    }

    // ---------------------------------------------------------------- events from real players

    void onPlayerChat(String player, String rawText) {
        // may be called from the async chat thread: hop to main thread
        Bukkit.getScheduler().runTask(plugin, () -> handleChat(player, rawText));
    }

    private void handleChat(String player, String rawText) {
        if (!enabled) {
            return;
        }
        String clean = Guard.in(rawText);
        if (clean.isBlank()) {
            return;
        }
        ChatLine line = new ChatLine(player, clean, false);
        addHistory(line);

        Bot direct = findMentioned(clean);
        if (direct != null) {
            respond(direct, line, true, 0);
            return;
        }
        if (rnd.nextDouble() < cfg().getDouble("chat.reply-chance-general", 0.22)) {
            Bot b = pickSpeaker(null);
            if (b != null) {
                respond(b, line, false, 0);
            }
        }
    }

    void welcome(String player) {
        react("chatter.welcome", player, cfg().getDouble("chat.welcome-chance", 0.45), 60 + rnd.nextInt(100));
    }

    void deathReact(String player) {
        react("chatter.death-react", player, cfg().getDouble("chat.death-react-chance", 0.4), 30 + rnd.nextInt(60));
    }

    private void react(String path, String player, double chance, long extraTicks) {
        if (!enabled || rnd.nextDouble() > chance) {
            return;
        }
        Bot b = pickSpeaker(null);
        String line = plugin.offline().pickLine(path);
        if (b == null || line == null) {
            return;
        }
        speak(b, line.replace("{player}", player), 1, extraTicks);
    }

    private Bot findMentioned(String text) {
        Set<String> tokens = new HashSet<>(Arrays.asList(text.toLowerCase(Locale.ROOT).split("[^a-z0-9_]+")));
        for (Bot b : roster) {
            if (!b.online) {
                continue;
            }
            for (String a : b.p.aliases()) {
                if (tokens.contains(a)) {
                    return b;
                }
            }
        }
        return null;
    }

    private Bot pickSpeaker(Bot exclude) {
        long now = System.currentTimeMillis();
        long cd = cfg().getInt("chat.bot-cooldown-seconds", 10) * 1000L;
        List<Bot> c = new ArrayList<>();
        for (Bot b : roster) {
            if (b.online && b != exclude && now - b.lastSpoke > cd) {
                c.add(b);
            }
        }
        return c.isEmpty() ? null : c.get(rnd.nextInt(c.size()));
    }

    // ---------------------------------------------------------------- speaking

    private void respond(Bot b, ChatLine trig, boolean direct, int depth) {
        long now = System.currentTimeMillis();
        long gap = cfg().getInt("chat.min-gap-seconds", 3) * 1000L;
        if (now - lastAny < gap) {
            return;
        }
        lastAny = now; // reserve the slot so bursts cannot happen
        List<ChatLine> hist = snapshot();
        generate(b.p, hist, trig, direct).thenAccept(r -> {
            if (r != null && !r.isBlank()) {
                Bukkit.getScheduler().runTask(plugin, () -> speak(b, r, depth, 0));
            }
        });
    }

    private CompletableFuture<String> generate(Persona p, List<ChatLine> hist, ChatLine trig, boolean direct) {
        String mode = cfg().getString("brain.mode", "AUTO").toUpperCase(Locale.ROOT);
        if (mode.equals("OFFLINE") || !plugin.api().available()) {
            if (mode.equals("API")) {
                return CompletableFuture.completedFuture("");
            }
            return CompletableFuture.completedFuture(offlineAnswer(p, trig, direct));
        }
        return plugin.api().reply(p, hist, trig, direct).thenApply(r -> {
            if (r != null) {
                return r;
            }
            return mode.equals("AUTO") ? offlineAnswer(p, trig, direct) : "";
        });
    }

    private String offlineAnswer(Persona p, ChatLine trig, boolean direct) {
        String s = trig == null ? plugin.offline().ambient(p) : plugin.offline().reply(p, trig, direct);
        return s == null ? "" : s;
    }

    /** Runs on the main thread. Filters, humanizes, waits a "typing" delay, then posts. */
    private void speak(Bot b, String raw, int depth, long extraTicks) {
        String clean = Guard.out(raw, cfg().getStringList("blocked-words"), plugin.api().key());
        if (clean == null) {
            return;
        }
        String msg = Humanizer.apply(clean, b.p, rnd);
        long delay = Humanizer.delayTicks(msg, rnd) + extraTicks;
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            if (!b.online || !enabled) {
                return;
            }
            send(b, msg);
            if (depth < 1 && rnd.nextDouble() < cfg().getDouble("chat.chain-chance", 0.12)) {
                Bot other = pickSpeaker(b);
                if (other != null) {
                    ChatLine line = new ChatLine(b.p.name(), msg, true);
                    Bukkit.getScheduler().runTaskLater(plugin, () -> respond(other, line, false, 1), 40L + rnd.nextInt(60));
                }
            }
        }, delay);
    }

    private void send(Bot b, String msg) {
        String fmt = cfg().getString("chat.format", "&7{name} &8» &f{message}");
        // msg is already stripped of color codes by Guard, so it cannot inject formatting
        Bukkit.broadcast(legacy.deserialize(fmt.replace("{name}", b.p.name()).replace("{message}", msg)));
        b.lastSpoke = System.currentTimeMillis();
        lastAny = b.lastSpoke;
        addHistory(new ChatLine(b.p.name(), msg, true));
    }

    /** Admin command: make a bot say something (still filtered, no typing delay). */
    boolean forceSay(Bot b, String text) {
        String clean = Guard.out(text, cfg().getStringList("blocked-words"), plugin.api().key());
        if (clean == null) {
            return false;
        }
        if (!b.online) {
            join(b);
        }
        send(b, clean);
        return true;
    }

    /** Admin command: run the brain privately and hand the answer back (not broadcast). */
    CompletableFuture<String> test(String fromName, String text) {
        Bot b = null;
        for (Bot x : roster) {
            if (x.online) {
                b = x;
                break;
            }
        }
        if (b == null) {
            return CompletableFuture.completedFuture(null);
        }
        ChatLine line = new ChatLine(fromName, Guard.in(text), false);
        List<ChatLine> hist = new ArrayList<>(snapshot());
        hist.add(line);
        Persona p = b.p;
        return generate(p, hist, line, true).thenApply(r -> r == null || r.isBlank() ? null : p.name() + ": " + r);
    }

    // ---------------------------------------------------------------- history & helpers

    private void addHistory(ChatLine l) {
        int max = Math.max(2, cfg().getInt("chat.history-lines", 8));
        synchronized (history) {
            history.addLast(l);
            while (history.size() > max) {
                history.removeFirst();
            }
        }
    }

    private List<ChatLine> snapshot() {
        synchronized (history) {
            return new ArrayList<>(history);
        }
    }

    private int rand(int min, int max) {
        if (max <= min) {
            return min;
        }
        return min + rnd.nextInt(max - min + 1);
    }

    private static long ms(int seconds) {
        return seconds * 1000L;
    }
}
