package dev.lifepals;

import java.io.File;
import org.bukkit.command.PluginCommand;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.plugin.java.JavaPlugin;

public final class LifePals extends JavaPlugin {
    private YamlConfiguration knowledge;
    private BotManager bots;
    private ApiBrain api;
    private OfflineBrain offline;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        for (String f : new String[]{"knowledge.yml", "personas.yml"}) {
            if (!new File(getDataFolder(), f).exists()) {
                saveResource(f, false);
            }
        }
        loadKnowledge();
        api = new ApiBrain(this);
        offline = new OfflineBrain(this);
        bots = new BotManager(this);

        getServer().getPluginManager().registerEvents(new Events(this), this);
        Commands cmd = new Commands(this);
        PluginCommand pc = getCommand("pals");
        if (pc != null) {
            pc.setExecutor(cmd);
            pc.setTabCompleter(cmd);
        }
        bots.start();
        getServer().getScheduler().runTaskTimerAsynchronously(this, () -> api.resetBudget(), 72000L, 72000L);
        getLogger().info("LifePals enabled. Brain mode: " + getConfig().getString("brain.mode", "AUTO"));
    }

    @Override
    public void onDisable() {
        if (bots != null) {
            bots.stop();
        }
    }

    private void loadKnowledge() {
        knowledge = YamlConfiguration.loadConfiguration(new File(getDataFolder(), "knowledge.yml"));
    }

    void reloadAll() {
        reloadConfig();
        loadKnowledge();
        bots.reload();
    }

    YamlConfiguration knowledge() {
        return knowledge;
    }

    BotManager bots() {
        return bots;
    }

    ApiBrain api() {
        return api;
    }

    OfflineBrain offline() {
        return offline;
    }
}
