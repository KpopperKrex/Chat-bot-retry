package dev.lifepals;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;

record Persona(String name, String lang, String style, int daysPlaying, double typoRate, List<String> aliases) {

    static Persona fromMap(Map<?, ?> m) {
        String name = String.valueOf(m.get("name"));
        String lang = m.get("lang") != null ? String.valueOf(m.get("lang")).toLowerCase(Locale.ROOT) : "hinglish";
        String style = m.get("style") != null ? String.valueOf(m.get("style")) : "chill";
        int days = m.get("days") instanceof Number dn ? dn.intValue() : 30;
        double typo = m.get("typo") instanceof Number tn ? tn.doubleValue() : 0.1;

        List<String> aliases = new ArrayList<>();
        String lower = name.toLowerCase(Locale.ROOT);
        aliases.add(lower);
        for (String part : lower.split("[_\\d]+")) {
            if (part.length() >= 3 && !aliases.contains(part)) {
                aliases.add(part);
            }
        }
        return new Persona(name, lang, style, days, typo, aliases);
    }

    boolean hinglish() {
        return !lang.equals("english");
    }
}
